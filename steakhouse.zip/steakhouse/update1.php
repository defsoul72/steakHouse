<?php
require('dbconnect.php');
session_start();
// $cust_id = $_SESSION['cust_id']; 

 
$cust_id = $_POST['cust_id'];
$cust_name = $_POST['cust_name'];
$cust_add = $_POST['cust_add'];
$cust_pno = $_POST['cust_pno'];
$cust_email = $_POST['cust_email']; 
 
	
	$sql = "UPDATE customer set cust_name = '$cust_name' , cust_add = '$cust_add', cust_pno = '$cust_pno', cust_email = '$cust_email' 
	       WHERE cust_id = '$cust_id' ";
	$result = mysqli_query($mysqli, $sql);
	
	
	if($result) //success  
	   {
	   	
			mysqli_commit($mysqli);
			Print '<script>alert("Your information has been updated.");</script>'; 
			Print '<script>window.location.assign("custUpdate.php?cust_id='.$cust_id.'");</script>'; 
		}
		else //unsuccess  
		{
			mysqli_rollback($mysqli);

			Print '<script>alert(" Update fail, try again next time.");</script>'; 
			Print '<script>window.location.assign("custUpdate.php?cust_id='.$cust_id.'");</script>'; 		
		}
?>
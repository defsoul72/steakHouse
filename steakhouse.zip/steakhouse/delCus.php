<?php
 require'db.php';
session_start();
	
$cust_id = $_GET['cust_id'];
  $sql = "DELETE FROM customer WHERE cust_id ='$cust_id'";



 	 $result = mysqli_query($mysqli, $sql);



 if($result)

 {

 	mysqli_commit($mysqli);

		Print '<script> alert("Order has been deleted.") </script>'; 

		Print '<script>window.location.assign("custData.php?cust_id='.$cust_id.'");</script>'; 

		}

		else //unsuccess  

		{

			mysqli_rollback($mysqli);



			Print '<script>alert("Fail to delete");</script>'; 

			Print '<script>window.location.assign("custData.php?cust_id='.$cust_id.'");</script>'; 		

		}



?>
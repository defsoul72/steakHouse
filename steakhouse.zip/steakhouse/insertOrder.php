
<?php
require('dbconnect.php');
session_start();
 $cust_id = $_SESSION['cust_id']; 

// If form submitted, insert values into the database.
if (isset($_REQUEST['submit']))
{
        // removes backslashes
  $cust_name = stripslashes($_REQUEST['cust_name']);
  $cust_name = mysqli_real_escape_string($mysqli,$cust_name);
  $cust_add = stripslashes($_REQUEST['cust_add']);
  $cust_add = mysqli_real_escape_string($mysqli,$cust_add);
  $cust_pno = stripslashes($_REQUEST['cust_pno']);
  $cust_pno = mysqli_real_escape_string($mysqli,$cust_pno);
  $cust_email = stripslashes($_REQUEST['cust_email']);
  $cust_email = mysqli_real_escape_string($mysqli,$cust_email); 
 

  $gender = stripslashes($_REQUEST['gender']);
  $gender = mysqli_real_escape_string($mysqli,$gender);

  $dob = stripslashes($_REQUEST['dob']);
  $dob = mysqli_real_escape_string($mysqli,$dob);
  $trn_date = date("d-m-y H:i:s");

$sql = "INSERT into user VALUES ('','$username','$password','$fname', '$lname','$address', '$city', '$state', '$postal', '$contact','$email', '$gender', '$dob', '$trn_date')";

$result = mysqli_query($mysqli,$sql);
if($result)
{
    mysqli_commit($mysqli);
    print '<script>window.location.assign("yey.php");</script>';  
    $_SESSION['username'] = $_POST['username'];
}
      

else
    { 
    // mysqli_rollback($mysqli);
    echo " Opss... the server is under maintenace, try again later ";
}

}
?>
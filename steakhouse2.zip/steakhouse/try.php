<?php
<form action="process.php" method="post">
<input type="text" name="myText" />
<input type="checkbox" name="myCheck" value="someVal" />
<input type="sumbit" />
</form>

?>


<?php
require('dbconnect.php');
session_start();


if (isset($_REQUEST['submit']))
{

if(isset( $_POST["menu"] ))
  {     
      $type = $_POST["menu"];
      $c = count($type);
      $price = 0.0;
   		$total = 0.0;

    print '<table width="700px" border="2" cellpadding="5" cellpadding="10" align="center" style="background-color:white;">';

                  print "<tr> <td colspan=1><b> Your Order </b> </td><td colspan=2> <b>Price </b></td> </tr>" ;

         for($i=0;$i<$c;$i++)
         {
         	  // $total += $price ; 

              if($type[$i] == 1)
              {
                   
                  $price = 20;
                  $food ="Ham Sandwiches<br>";

                  print "<tr> <td > " .$food. "</td><td colspan=2 > $ " .$price. "</td> </tr>";

                  $field = isset($_POST['menu']) ? $_POST['menu'] : false;
				 $dbFlag = $field ? 'Yes' : 'No';
                 
                 foreach ($_POST['menu'] as $pageId => $likeFlag) 
                 {
   					 $dbFlag = $likeFlag ? 'Yes' : 'No';

     
		            }  

                    $order_name = stripslashes($_REQUEST['menu']);
 					$order_name = mysqli_real_escape_string($mysqli,$order_name);
    		 
   
                   // echo  "&nbsp;&nbsp;" .$quantity1." Malaysian Adult <br>";
              }

              if($type[$i] == 2){
                    
                   $price = 18;
                   $food ="Potato Sandwiches  <br>";
                    
                 print "<tr> <td > " .$food. "</td><td colspan=2 > $ " .$price. "</td> </tr>";

                   $order_name = stripslashes($_REQUEST['menu']);
 					$order_name = mysqli_real_escape_string($mysqli,$order_name);
    		 


                     // echo  "&nbsp;&nbsp;" .$quantity2." Malaysian Child <br>";
                 
              }

              if($type[$i] == 3){
                  
                   $price = 60;
                   $food ="Beef Steak  <br>";
                    
                    print "<tr> <td > " .$food. "</td><td colspan=2 > $ " .$price. "</td>  </tr>";

                  // echo  "&nbsp;&nbsp;" .$quantity3." Non Malaysian Adult <br>";
              }

              if($type[$i] == 4){

                   $price = 180;
                   $food ="BlackPepper Steak <br>";
                   
                   print "<tr> <td > " .$food. "</td><td colspan=2 > $ " .$price. "</td>  </tr>";

              //     echo  "&nbsp;&nbsp;" .$quantity4." Non Malaysian Child <br>";
              // }
                }//end for.

                 if($type[$i] == 5){

                   $price = 150;
                   $food ="Ribeye Steak <br>";
                    
                    print "<tr> <td > " .$food. "</td><td colspan=2 > $ " .$price. "</td>  </tr>";

              //     echo  "&nbsp;&nbsp;" .$quantity4." Non Malaysian Child <br>";
              // }
                }

                 if($type[$i] == 6){

                   $price = 5;
                   $food ="Mushroom Soup   <br>";
                   
                   print "<tr> <td > " .$food. "</td><td colspan=2 > $ " .$price. "</td>  </tr>";

              //     echo  "&nbsp;&nbsp;" .$quantity4." Non Malaysian Child <br>";
              // }
                }

                 if($type[$i] == 7){

                   $price = 23;
                   $food ="Macaronni  <br>";
                  
                   print "<tr> <td > " .$food. "</td><td colspan=2 > $ " .$price. "</td>  </tr>";
 				
              //     echo  "&nbsp;&nbsp;" .$quantity4." Non Malaysian Child <br>";
              // }
                }
			   $total += $price ; 

				 $total = stripslashes($_REQUEST['order_price']);
			  	$total = mysqli_real_escape_string($mysqli,$total);
           		$sql = "INSERT into ordering VALUES ('','$username','$password','$fname', '$lname','$address', '$city', '$state', '$postal', '$contact','$email', '$gender', '$dob', '$trn_date')";
         // print '<input type="text" name="total" value="<?php echo $price; 
        
           }
           // echo "<br>TOTALSS PRICE <br> MYR: " .$price. "<br><br>";
         

 	  print "<tr> <td colspan=3 align=center><b>Total Price : $ " .$total. "  </b> </td> </tr>";

        }
 
 
print "<tr> <td colspan=3 align=center>  <a href=#payment><button > Make A Payment </button></a></td> </tr>";
 		print '</table> <br><br><br>';			

 	}
?>

	 
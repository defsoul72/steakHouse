 <?php
require('dbconnect.php'); 
session_start();

echo $cust_id = $cust_name; 

     //  $sql = "SELECT * FROM `customer` WHERE `cust_id`='$cust_id'";
     // $result = mysqli_query($mysqli, $sql);
     // $row = mysqli_fetch_assoc($result);
?>


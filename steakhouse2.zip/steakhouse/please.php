
<?php

require('dbconnect.php');
 
$hamSandwiches = $_POST['hamSandwiches'];
    $potatoSandwiches = $_POST['potatoSandwiches'];
 
if (isset($_REQUEST['order']))
{
          

    $hamSandwiches = stripslashes($_REQUEST['hamSandwiches']);
    $hamSandwiches = mysqli_real_escape_string($mysqli,$hamSandwiches);
    $potatoSandwiches = stripslashes($_REQUEST['potatoSandwiches']);
    $potatoSandwiches = mysqli_real_escape_string($mysqli,$potatoSandwiches);
     
    // $total = stripslashes($_REQUEST['total']);
    // $total = mysqli_real_escape_string($mysqli,$price);

  
$sql = "INSERT into ordering VALUES ('', '$hamSandwiches', '$potatoSandwiches' )";

$result = mysqli_query($mysqli,$sql);

if($result) //success  
       {
        
            mysqli_commit($mysqli);
            Print '<script>alert("Your information has been recorded.");</script>'; 
            Print '<script>window.location.assign("order2.php?cust_id='.$cust_id.'");</script>'; 
        }
        else //unsuccess  
        {
            mysqli_rollback($mysqli);

            Print '<script>alert(" Update fail, try again next time.");</script>'; 
            Print '<script>window.location.assign("please.php");</script>';        
        }

 

 
}

?>

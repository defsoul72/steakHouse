<?php
require('dbconnect.php');
session_start();

$cust_id = $_SESSION['cust_id']; 
$hamSandwiches=$_POST['hamSandwiches']; 
$potatoSandwiches=$_POST['potatoSandwiches']; 

 

if (isset($_REQUEST['submit']))
{

	$hamSandwiches = stripslashes($_REQUEST['hamSandwiches']);
    $hamSandwiches = mysqli_real_escape_string($mysqli,$hamSandwiches);
    $potatoSandwiches = stripslashes($_REQUEST['potatoSandwiches']);
    $potatoSandwiches = mysqli_real_escape_string($mysqli,$potatoSandwiches);
     
     $sql = "INSERT into ordering VALUES ('', '$hamSandwiches', '$potatoSandwiches' , '$cust_id' )";

 $result = mysqli_query($mysqli,$sql);
if($result)
{
    mysqli_commit($mysqli);
    echo "<p align=center><br> Your information have been recorded! Kindly please print the ticket for reference</p> <br>";
}
else
    {
    rollback($mysqli);
    echo " Opss... the server is under maintenace, try again later ";
}


    
// $cust_id = $_POST['cust_id'];
// $cust_name = $_POST['cust_name'];
// $cust_add = $_POST['cust_add'];
// $cust_pno = $_POST['cust_pno'];
// $cust_email = $_POST['cust_email']; 
 
	
// 	$sql = "UPDATE customer set cust_name = '$cust_name' , cust_add = '$cust_add', cust_pno = '$cust_pno', cust_email = '$cust_email' 
// 	       WHERE cust_id = '$cust_id' ";
// 	$result = mysqli_query($mysqli, $sql);
	
	
// 	if($result) //success  
// 	   {
	   	
// 			mysqli_commit($mysqli);
// 			Print '<script>alert("Your information has been updated.");</script>'; 
// 			Print '<script>window.location.assign("waiting.html?cust_id='.$cust_id.'");</script>'; 
// 		}
// 		else //unsuccess  
// 		{
// 			mysqli_rollback($mysqli);

// 			Print '<script>alert(" Update fail, try again next time.");</script>'; 
// 			Print '<script>window.location.assign("order1.php?cust_id='.$cust_id.'");</script>'; 		
// 		}
?>